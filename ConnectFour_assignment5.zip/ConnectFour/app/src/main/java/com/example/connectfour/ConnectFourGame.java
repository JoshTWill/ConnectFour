package com.example.connectfour;

public class ConnectFourGame {
    private int[][] Board;
    public static final int ROW = 7;
    public static final int COL = 6;
    public static final int EMPTY = 0;
    public static final int BLUE = 1;
    public static final int RED = 2;
    public static final int DISCS = 42;

    int player = BLUE;
    int discCount = 0;


        public ConnectFourGame() {
        Board = new int[ROW][COL];
        discCount = 0;
    }

        public void newGame() {

        for (int row = 0; row < ROW; row++) {
            for (int col = 0; col < COL; col++) {
                Board[row][col] = 0;
            }
       player = BLUE;

        }
    }

        public String getState () {
            StringBuilder boardString = new StringBuilder();
            for (int row = 0; row < ROW; row++) {
                for (int col = 0; col < COL; col++) {
                    boardString.append(Board[row][col]);
                }
            }

            return boardString.toString();
        }

        public boolean isGameOver(){

            return discCount == DISCS ||  isWin();
        }

        public boolean isWin() {
            return checkHorizontal() || checkVertical() || checkDiagonal();
        }

        public boolean checkHorizontal(){
            for (int row = 0; row < ROW; row++) {
                for (int col = 0; col <= COL - 4; col++) {
                    // Check for four consecutive discs of the same color horizontally
                    if (Board[row][col] != 0 &&
                            Board[row][col] == Board[row][col + 1] &&
                            Board[row][col] == Board[row][col + 2] &&
                            Board[row][col] == Board[row][col + 3]) {
                        return true;
                    }
                }
            }

            return false;
        }

        public boolean checkVertical(){
        for (int col = 0; col < COL; col++) {
            for (int row = 0; row <= ROW - 4; row++) {
                // Check for four consecutive discs of the same color vertically
                if (Board[row][col] != 0 &&
                        Board[row][col] == Board[row + 1][col] &&
                        Board[row][col] == Board[row + 2][col] &&
                        Board[row][col] == Board[row + 3][col]) {
                    return true;
                }
            }
        }


        return false;
    }

        public boolean checkDiagonal(){
        // Check from top-left to bottom-right
        for (int row = 0; row <= ROW - 4; row++) {
            for (int col = 0; col <= COL - 4; col++) {
                // Check for four consecutive discs of the same color diagonally
                if (Board[row][col] != 0 &&
                        Board[row][col] == Board[row + 1][col + 1] &&
                        Board[row][col] == Board[row + 2][col + 2] &&
                        Board[row][col] == Board[row + 3][col + 3]) {
                    return true;
                }
            }
        }

        // Check from top-right to bottom-left
        for (int row = 0; row <= ROW - 4; row++) {
            for (int col = 3; col < COL; col++) {
                // Check for four consecutive discs of the same color diagonally
                if (Board[row][col] != 0 &&
                        Board[row][col] == Board[row + 1][col - 1] &&
                        Board[row][col] == Board[row + 2][col - 2] &&
                        Board[row][col] == Board[row + 3][col - 3]) {
                    return true;
                }
            }
        }

        return false;
    }

        public int getDisc(int row, int col){

            return Board[row][col];
        }

        public void setState(String gameState){
            int index = 0;
            for (int row = 0; row < ROW; row++) {
                for (int col = 0; col < COL; col++) {
                    Board[row][col] = gameState.charAt(index);
                    index++;
                }
            }
        }

        public void selectDisc(int row, int col){

            discCount += 1;
            int discRow = ROW - 1;

            for(int i=0; i< ROW; i++) {
                if(Board[i][col] != EMPTY){
                    discRow = i -1;
                    break;
                }
            }

            if (discRow > 0) {
                Board[discRow][col] = player;

                if(player == BLUE){
                    player = RED;
                } else{
                    player = BLUE;
                }
            }
        }
    }
