package com.example.connectfour;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class GameOptionsFragment extends Fragment {
    private RadioGroup mGroup;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)      {

        View parentView = inflater.inflate(R.layout.fragment_game_options,container,false);

        SharedPreferences sharedPref = requireActivity().getPreferences(Context.MODE_PRIVATE);
        int levelId = sharedPref.getInt("level", R.id.radio_easy);

        int radioId = R.id.radio_easy;
        if (levelId == R.id.radio_medium) {
            radioId = R.id.radio_medium;
        } else if (levelId == R.id.radio_hard) {
            radioId = R.id.radio_hard;
        }

        RadioButton rb = parentView.findViewById(radioId);
        rb.setChecked(true);

        mGroup = parentView.findViewById(R.id.RadioGroupCF);
        for (int i = 0; i < mGroup.getChildCount(); i++) {
            Button gridButton = (Button) mGroup.getChildAt(i);
            gridButton.setOnClickListener(this::onLevelSelected);
        }

        /*
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_game_options);


        easy = (RadioButton)findViewById(R.id.radio_easy);
        med = (RadioButton)findViewById(R.id.radio_medium);
        hard = (RadioButton)findViewById(R.id.radio_hard);*/
        return parentView;
    }

    public void onLevelSelected(View view) {

        int levelId = R.id.radio_easy;
        if (view.getId() == R.id.radio_medium) {
            levelId = R.id.radio_medium;
        } else if (view.getId() == R.id.radio_hard) {
            levelId = R.id.radio_hard;
        }

        // Save selected color ID in SharedPreferences
        SharedPreferences sharedPref = requireActivity().getPreferences(Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("level", levelId);
        editor.apply();
    }
}