package com.example.connectfour;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.drawable.DrawableCompat;
import androidx.fragment.app.Fragment;

import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.Toast;

public class BoardFragment extends Fragment {
    private final String GAME_STATE = "gameState";
    private ConnectFourGame mGame;
    private GridLayout mGrid;



   public View onCreateView(@NonNull LayoutInflater inflater,
                            ViewGroup container, Bundle savedInstanceState) {
        View parentView = inflater.inflate(R.layout.fragment_board,container,false);
        mGrid = parentView.findViewById(R.id.board_grid);

        for(int i=0; i<mGrid.getChildCount();i++){
            Button gridButton = (Button)mGrid.getChildAt(i);
            gridButton.setOnClickListener(this::onButtonClick);
        }

        mGame = new ConnectFourGame();

       if (savedInstanceState == null) {
           startGame();
       }else {
           String gameState = GAME_STATE;
           mGame.setState(gameState);
           setDisc();
       }


        return parentView;
    }

    private void onButtonClick(View view) {
       int buttonIndex = mGrid.indexOfChild(view);
       int row = buttonIndex / ConnectFourGame.COL;
       int col = buttonIndex % ConnectFourGame.COL;

       mGame.selectDisc(row, col);
       setDisc();

        if (mGame.isGameOver() == true) {
            Toast.makeText(this.requireActivity(), "Congratulations!", Toast.LENGTH_SHORT).show();
            mGame.newGame();
            setDisc();
        }
   }

   private void startGame(){
       mGame.newGame();
       setDisc();
   }

   private void setDisc(){
       for (int buttonIndex = 0; buttonIndex < mGrid.getChildCount(); buttonIndex++) {
           Button gridButton = (Button) mGrid.getChildAt(buttonIndex);

           // Find the button's row and col
           int row = buttonIndex / ConnectFourGame.COL;
           int col = buttonIndex % ConnectFourGame.COL;

           Drawable white =  ContextCompat.getDrawable(getActivity(), R.drawable.circle_white  );
           Drawable red = ContextCompat.getDrawable(getActivity(), R.drawable.circle_red);
           Drawable blue = ContextCompat.getDrawable(getActivity(),R.drawable.circle_blue );

           white = DrawableCompat.wrap(white);
           red = DrawableCompat.wrap(red);
           blue = DrawableCompat.wrap(blue);

          int disc = mGame.getDisc(row, col);

          if(disc == ConnectFourGame.BLUE){
              gridButton.setBackground(blue);

          }else if(disc == ConnectFourGame.RED){
              gridButton.setBackground(red);
          }else if(disc == ConnectFourGame.EMPTY){
              gridButton.setBackground(white);
          }else {
              Toast.makeText(this.requireActivity(), "SOMETHING WENT WRONG!!", Toast.LENGTH_SHORT).show();
          }
       }


   }





    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString(GAME_STATE, mGame.getState());
    }

}